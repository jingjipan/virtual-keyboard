from __future__ import print_function
import csv
import matplotlib.pyplot as plt
emgTime=[]
emg1=[]
emg2=[]
emg3=[]
emg4=[]
emg5=[]
emg6=[]
emg7=[]
emg8=[]
emgsum=[]
csv_reader = csv.reader(open('C:\\Users\\Jingji Pan\\Desktop\\Myo Keyboard Data\\Backward\\emg-1456704054.csv', encoding='utf-8'))
for row in csv_reader:
    emgTime.append(row[0])
    emg1.append(row[1])
    emg2.append(row[2])
    emg3.append(row[3])
    emg4.append(row[4])
    emg5.append(row[5])
    emg6.append(row[6])
    emg7.append(row[7])
    emg8.append(row[8])
del emgTime[0]
del emg1[0]
del emg2[0]
del emg3[0]
del emg4[0]
del emg5[0]
del emg6[0]
del emg7[0]
del emg8[0]
for i in range(len(emg1)):
    #emgsum.append(int(emg1[i])+int(emg2[i])+int(emg3[i])+int(emg4[i])+int(emg5[i])+int(emg6[i])+int(emg7[i])+int(emg8[i]))
    emgsum.append(int(emg1[i]) + int(emg3[i]) +  int(emg5[i]) +  int(emg7[i]) )
#plt.plot(emgTime,emg1,label='1')
#plt.plot(emgTime,emg2,label='2')
#plt.plot(emgTime,emg3,label='3')
#plt.plot(emgTime,emg4,label='4')
#plt.plot(emgTime,emg5,label='5')
#plt.plot(emgTime,emg6,label='6')
#plt.plot(emgTime,emg7,label='7')
#plt.plot(emgTime,emg8,label='8')
plt.plot(emgTime,emgsum,label='8')

plt.show()